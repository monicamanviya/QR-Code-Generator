package com.QRCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
