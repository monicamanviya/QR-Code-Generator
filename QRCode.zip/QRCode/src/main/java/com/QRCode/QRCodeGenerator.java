package com.QRCode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.net.URL;

public class QRCodeGenerator {

    public static void generateQRCodeImage(String url, int width, int height, String filePath) throws WriterException, IOException {
        //validate for valid url
        if (validateUrl(url)) {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(url, BarcodeFormat.QR_CODE, width, height);

            Path path = FileSystems.getDefault().getPath(filePath);
            MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);
        }
        else
            System.out.println("Please Enter Valid URL string");
    }

    public  static  boolean validateUrl(String url){
            try {
                new URL(url).toURI();
                return true ;
            }
            catch (Exception e) {
                return false;
            }
    }

}
